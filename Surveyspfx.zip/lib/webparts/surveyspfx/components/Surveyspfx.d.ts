import * as React from 'react';
import type { ISurveyspfxProps } from './ISurveyspfxProps';
export interface ISPLists {
    value: ISPList[];
}
export interface ISPList {
    Title: string;
    Id: string;
}
export default class Surveyspfx extends React.Component<ISurveyspfxProps, any> {
    constructor(props: any);
    componentDidMount(): void;
    componentDidUpdate(): void;
    private _getListData;
    render(): React.ReactElement<ISurveyspfxProps>;
}
//# sourceMappingURL=Surveyspfx.d.ts.map