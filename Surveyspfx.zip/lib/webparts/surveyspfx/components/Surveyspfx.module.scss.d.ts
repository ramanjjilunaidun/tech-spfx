declare const styles: {
    surveyspfx: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Surveyspfx.module.scss.d.ts.map