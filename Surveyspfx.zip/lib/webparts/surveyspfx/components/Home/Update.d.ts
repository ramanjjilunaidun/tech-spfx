/// <reference types="react" />
export declare const Update: (props: any) => JSX.Element;
//# sourceMappingURL=Update.d.ts.map