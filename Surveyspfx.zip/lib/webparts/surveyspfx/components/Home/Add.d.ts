/// <reference types="react" />
export declare const Add: (props: any) => JSX.Element;
//# sourceMappingURL=Add.d.ts.map