/// <reference types="react" />
export declare const Display: (props: any) => JSX.Element;
//# sourceMappingURL=Display.d.ts.map