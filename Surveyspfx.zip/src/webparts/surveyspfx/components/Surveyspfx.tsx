import * as React from 'react';
import styles from './Surveyspfx.module.scss';
import type { ISurveyspfxProps } from './ISurveyspfxProps';
import { Button, Typography } from 'antd'
import { Display } from './Home/Display'
import { Add } from './Home/Add'
// import { v4 as uuidv4 } from 'uuid'
const { Title } = Typography

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';
export interface ISPLists {
  value: ISPList[];
}

export interface ISPList {
  Title: string;
  Id: string;
}
let currentWebUrl= "https://7t8zz6.sharepoint.com/sites/SP";

export default class Surveyspfx extends React.Component<ISurveyspfxProps,any> {
  constructor(props: any) {
    super(props);
    this.state = {
      open: false,
      persons: [{} as any],
    }
  }

  componentDidMount(): void {
      this._getListData();
  }

  componentDidUpdate(): void {
    this._getListData();
  }

  private _getListData()  {
      //let url = this.context.pageContext.web.absoluteUrl;
      
      let requestUrl = currentWebUrl.concat("/_api/web/Lists/GetByTitle('Surveys')/items")

this.props.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
            if (response.ok) {
                response.json().then((responseJSON) => {
                    if (responseJSON!=null && responseJSON.value!=null){
                        let items:any[] = responseJSON.value;
                        this.setState({persons: items});
                        return items;
                    }
                });
            }
        });
      
  }
  public render(): React.ReactElement<ISurveyspfxProps> {
    const {
      hasTeamsContext,
    } = this.props;

    const showModal = () => {
      this.setState({open:true})
    }

    const handleUpdate = (
    ) => {
      // private updateItem = (): void => {
      //   const id: number = document.getElementById('itemId')['value'];
      //   const body: string = JSON.stringify({
      //     'Title': document.getElementById("fullName")['value'],
      //     'Age': document.getElementById("age")['value']
      //   });
      //   if (id > 0) {
      //     this.props.context.spHttpClient.post(`${this.props.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('EmployeeDetails')/items(${id})`,
      //       SPHttpClient.configurations.v1,
      //       {
      //         headers: {
      //           'Accept': 'application/json;odata=nometadata',
      //           'Content-type': 'application/json;odata=nometadata',
      //           'odata-version': '',
      //           'IF-MATCH': '*',
      //           'X-HTTP-Method': 'MERGE'
      //         },
      //         body: body
      //       })
      //       .then((response: SPHttpClientResponse) => {
      //         if (response.ok) {
      //           alert(`Item with ID: ${id} updated successfully!`);
      //         } else {
      //           response.json().then((responseJSON) => {
      //             console.log(responseJSON);
      //             alert(`Something went wrong! Check the error in the browser console.`);
      //           });
      //         }
      //       }).catch(error => {
      //         console.log(error);
      //       });
      //   }
      //   else {
      //     alert(`Please enter a valid item id.`);
      //   }
      // }
    }
  
    const handleOk = (
      user : any,
      country: any,
      department : any,
      dueDate : any,
      title : any,
      description : any,
      rating: any
    ) => {    


      // Creata Item code
      const body: string = JSON.stringify({
        'User': user,
        'Department': department,
        'DueDate': dueDate,
        'Country': country,
        'Description' : description,
        'Ratings': rating,
        'Title' : title,
      });
      // let url = this.context.pageContext.web.absoluteUrl;

      const requestUrl = currentWebUrl.concat("/_api/web/lists/getbytitle('Surveys')/items");
      this.props.spHttpClient.post(requestUrl,
        SPHttpClient.configurations.v1, {
        headers: {
          'Accept': 'application/json;odata=nometadata',
          'Content-type': 'application/json;odata=nometadata',
          'odata-version': ''
        },
        body: body
      })
        .then((response: SPHttpClientResponse) => {
          if (response.ok) {
            response.json().then((responseJSON) => {
              alert(`Item created successfully with ID: ${responseJSON.ID}`);
            });
          } else {
            response.json().then((responseJSON) => {
              alert(`Something went wrong! Check the error in the browser console.`);
            });
          }
        }).catch(error => {
          console.log(error);
        });
        
      this.setState({open: false});

    }
  
    const handleCancel = () => {
      this.setState({open: false})
    }

    return (
      <section className={`${styles.surveyspfx} ${hasTeamsContext ? styles.teams : ''}`}>
    <div className='App'>
      <div className='text-center mt-4'>
        <Title>Surveys</Title>
      </div>
      <div>
        <div className='text-center mt-4'>
          <div style={{'display': 'flex','justifyContent': 'flex-end'}}>
          <Button
            type='primary'
            shape='round'
           // icon={<UserAddOutlined />}
           size='large'
            onClick={showModal}
          >
            Add Survey
          </Button>
          </div>
          <Display handleUpdate={handleUpdate} persons={this.state.persons} />
          <Add
            handleCancel={handleCancel}
            handleOk={handleOk}
            open={this.state.open}
          />
        </div>
      </div>
    </div>
        
      </section>
    );
  }
}
