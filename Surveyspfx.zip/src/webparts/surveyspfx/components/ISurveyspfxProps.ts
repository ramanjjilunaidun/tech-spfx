import { SPHttpClient } from "@microsoft/sp-http";

export interface ISurveyspfxProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spHttpClient: SPHttpClient;
}
