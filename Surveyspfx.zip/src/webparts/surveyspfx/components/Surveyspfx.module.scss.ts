/* tslint:disable */
require("./Surveyspfx.module.css");
const styles = {
  surveyspfx: 'surveyspfx_2a5961d7',
  teams: 'teams_2a5961d7',
  welcome: 'welcome_2a5961d7',
  welcomeImage: 'welcomeImage_2a5961d7',
  links: 'links_2a5961d7'
};

export default styles;
/* tslint:enable */