import * as React from 'react';
import { Table } from 'antd';
import { Update}  from './Update';
import { useState} from 'react';

export const Display = (props: any) => {
    const [open, setOpen] = useState(false)
    const [personRecord, setPersonRecord] = useState({} as any); 
    // const showModal = (id: any) => {
    //     alert(id);
    //     setPersonRecord(props.persons.find((person:any) => person.ID === id))
    //     setOpen(true);
    // }
  
   
    const handleCancel = () => {
      setOpen(false)
      setPersonRecord({})
    }
  
    const columns = [
        {
            title: 'User',
            dataIndex: 'User',
            key: 'User',
        },
        {
            title: 'Department',
            dataIndex: 'Department',
            key: 'Department',
        },
        {
            title: 'Country',
            dataIndex: 'Country',
            key: 'Country',
        },
        {
            title: 'DueDate',
            dataIndex: 'DueDate',
            key: 'DueDate',
        },
        {
            title: 'Title',
            dataIndex: 'Title',
            key: 'Title'
        },
        {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
        },
        
        {
            title: 'Ratings',
            dataIndex: 'Ratings',
            key: 'Ratings'
        },
        // {
        //     title: 'Update',
        //     dataIndex: 'update',
        //     key: 'update',
        //     render: (_ : any, record: any) => <Button
        //         type='link'
        //         shape='round'
        //         //icon={<EditOutlined />}
        //         size='large'
        //         onClick={() => showModal(record.ID)}
        //     >
        //     Update
        //   </Button>
        // }
    ]
    return(
        <>
        <Table columns={columns} dataSource={props.persons} className="mt-4"></Table>
        <Update
            key={personRecord}
            handleCancel={handleCancel}
            handleOk={props.handleUpdate}
            open={open}
            personRecord={personRecord}
          />        
        </>
    );
}

// Display.propTypes = {
//     persons: PropTypes.arrayOf(PropTypes.any),
//     setPersons: PropTypes.func,
// }