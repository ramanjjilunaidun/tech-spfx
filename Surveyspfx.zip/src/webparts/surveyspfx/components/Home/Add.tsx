import * as React from 'react';
import {  Form, Modal, Input, Select, DatePicker, Typography } from 'antd';
import { CountryDropdown } from 'react-country-region-selector';
import * as dayjs from 'dayjs';
import { useState } from 'react';

const { Option } = Select;
const { TextArea } = Input;
const {Text} = Typography;

export const Add = (props : any) => {
    const [user, setUser] = useState('');
    const [country, setCountry] = useState('');
    const [department, setDepartment] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [ratings, setRatings] = useState('');
    const [error, setError] = useState('');
    const clear = (event: any) => {
        event.preventDefault();
        setUser('');
        setCountry('');
        setDepartment('');
        setDueDate('');
        setTitle('');
        setRatings('');
        setDescription('');
        form.resetFields();
    };

    const onDateChange = (date: any, dateString: any) => {
        setDueDate(dateString);
    };
    const [form] = Form.useForm();

    const validate = () => {
        if(user !== '' && country !== '' && department!== '' && dueDate!=='' && title!=='' && description!='' && ratings!='') {
            setError('');
            return true;
        }
        setError('Please enter all values');
        return false;
    }
    return (
        <Modal
            title="Add Employee"
            open={props.open}
            onOk={() => {
                if(validate())
                    props.handleOk(user, country, department, dueDate, title, description, ratings)
            }}    
            confirmLoading={props.confirmLoading}
            onCancel={(e) => {
                clear(e);
                props.handleCancel();
            }}
            okText="Submit"
            cancelText="Clear"
                >
            <Form form={form}>
                <Form.Item label="User" name="User" 
                    rules={[{ required: true, message: 'Please input your name!' }]}>
                    <Input value={user} onChange={(e) => setUser(e.target.value)}/>
                </Form.Item>
                <Form.Item label="Country" name="country" rules={[{required: true, message: 'Please input your country!'}]}>
                <CountryDropdown
                    value={country}
                    onChange={(val) => setCountry(val)} />
                </Form.Item>
                <Form.Item label="Department" name="department" rules={[{required: true, message: 'Please input your department' }]}>
                    <Select value={department} onSelect={(val) => setDepartment(val)} allowClear>
                        <Option value="">Select Department</Option>
                        <Option value="IT">IT</Option>
                        <Option value="Sales">Sales</Option>
                        <Option value="HR">HR</Option>
                        <Option value="Accounts">Accounts</Option>
                    </Select>
                </Form.Item>
                <Form.Item label="DueDate" name="dueDate" rules={[{required: true, message: 'Please input your due date' }]}>
                    <DatePicker  minDate={dayjs()}onChange={onDateChange}/>
                </Form.Item>
                <Form.Item label="Title" name="title" rules={[{required: true, message: 'Please input title' }]}>
                    <Input value={title} onChange={(e) => setTitle(e.target.value)}/>
                </Form.Item>
                <Form.Item label="Ratings" name="ratings" rules={[{required: true, message: 'Please input ratings' }]}>
                    <Input value={ratings} onChange={(e) => setRatings(e.target.value)}/>
                </Form.Item>
                <Form.Item label="Description" name="description" rules={[{required: true, message: 'Please input descriptipn' }]}>
                    <TextArea rows={4} value={description} onChange={(e: any) => setDescription(e.target.value)}/>   
                </Form.Item>
                {error && <Form.Item>
                    <Text type="danger">{error}</Text>
                </Form.Item>}
            </Form>
       </Modal>
    )
}

// Add.propTypes = {
//     open: PropTypes.bool,
//     handleOk: PropTypes.func,
//     confirmLoading: PropTypes.bool,
//     handleCancel: PropTypes.func,
// }