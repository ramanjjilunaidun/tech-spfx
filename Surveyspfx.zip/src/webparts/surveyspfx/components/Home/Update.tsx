import * as React from 'react';
import {  Modal, Form, Input, Select, DatePicker } from 'antd';
import {CountryDropdown} from 'react-country-region-selector';
// import PropTypes from 'prop-types'
import { useState } from "react";
import * as dayjs from 'dayjs';

const {Option} = Select;
const {TextArea} = Input;

export const Update = (props:any) => {
    const [country, setCountry] = useState('');
    const [form] = Form.useForm();


    if(props.personRecord.Id)
    console.log(props.personRecord);
    return (
        <Modal
            title="Update Employee"
            open={props.open}
            onOk={(e) => {
                e.preventDefault()
                props.handleOk(
                    props.personRecord.Id, 
                    form.getFieldValue('User'), 
                    form.getFieldValue('Department'), 
                    form.getFieldValue('Country'), 
                    form.getFieldValue('DueDate').format('YYYY-MM-DD'), 
                    form.getFieldValue('Description'), 
                    form.getFieldValue('Title'),
                    form.getFieldValue('Ratings')
                )
            }}
            onCancel={(e) => {
                props.handleCancel();
            }}
            okText="Submit"
            cancelText="Clear"
        >
            <Form key={JSON.stringify(props.personRecord)} form={form} initialValues={{
                'user': props.personRecord?.User,
                'country': props.personRecord?.Country,
                'department': props.personRecord?.Department,
                'dueDate': dayjs(props.personRecord?.DueDate, 'YYYY-MM-DD'),
                'title': props.personRecord?.Title,
                'description': props.personRecord?.Description,
                'ratings': props.personRecord?.Ratings,
            }}>
                <Form.Item label="User" name="user" 
                    rules={[{ required: true, message: 'Please input your name!' }]}>
                    <Input/>
                </Form.Item>
                <Form.Item label="Country" name="country" rules={[{required: true, message: 'Please input your country!'}]}>
                <CountryDropdown value={country}
                    onChange={(val) => setCountry(val)}  />
                </Form.Item>
                <Form.Item label="Department" name="department" rules={[{required: true, message: 'Please input your department' }]}>
                    <Select >
                        <Option value="">Select Department</Option>
                        <Option value="IT">IT</Option>
                        <Option value="Sales">Sales</Option>
                        <Option value="HR">HR</Option>
                        <Option value="Accounts">Accounts</Option>
                    </Select>
                </Form.Item>
                <Form.Item label="DueDate" name="dueDate" rules={[{required: true, message: 'Please input your due date' }]}>
                    <DatePicker minDate={dayjs()} />
                </Form.Item>
                <Form.Item label="Title" name="title" rules={[{required: true, message: 'Please input title' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Ratings" name="ratings" rules={[{required: true, message: 'Please input rating' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Description" name="description" rules={[{required: true, message: 'Please input description' }]}>
                    <TextArea rows={4} />   
                </Form.Item>
            </Form>
       </Modal>
    )
}

// Update.propTypes = {
//     open: PropTypes.bool,
//     handleOk: PropTypes.func,
//     confirmLoading: PropTypes.bool,
//     handleCancel: PropTypes.func,
//     id: PropTypes.string,
//     persons: PropTypes.arrayOf(PropTypes.any), 
// }